public class Package {
    private int id;
    private double weight;
    private String destination;
    private String sender;

}
