package aula08;

public enum VariedadeCarne {
    FRANGO,VACA,PORCO,PERU,OUTRA;
}
