package aula08;

public interface Alimento {
    String getNome();
    double getProteinas();
    double getCalorias();
    double getPeso();
    boolean isVegetariano();
}
