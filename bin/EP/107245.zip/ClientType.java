package EP;

public enum ClientType{
    ENTERPRISE, PERSONAL;
}
