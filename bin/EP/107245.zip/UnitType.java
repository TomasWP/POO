package EP;

public enum UnitType {
    GARAGE

}
