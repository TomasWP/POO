package Util;

public class UserInput {
    public static boolean positivo_double(double number){
        if (number<0){
            System.out.println("Insira um valor positivo!\n");
            return true;
        } else{
            return false;
        }
    }

    public static boolean positivo_int(int number){
        if (number<0){
            System.out.println("Insira um valor positivo!\n");
            return true;
        } else{
            return false;
        }
    }

    public static boolean int_is_multiple(int number, int multiple_number){
        if (number%multiple_number == 0){
            return true;
        } else{
            return false;
        }
    }
}
