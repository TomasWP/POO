package Teste2;

public interface OrderCostCalculator {
    double calculateOrderCost(Order order);
}
