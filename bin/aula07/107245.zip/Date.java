package aula07;

public abstract class Date {

    public abstract void incrementDate();
    public abstract void decrementDate();
    public abstract String toString();

}
