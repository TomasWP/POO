package aula07;

public abstract class Forma {

    public abstract double getPerimetro();
    public abstract double getArea();
}
